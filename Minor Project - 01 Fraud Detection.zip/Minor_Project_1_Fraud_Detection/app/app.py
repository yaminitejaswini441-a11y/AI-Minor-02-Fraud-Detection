from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]

model = joblib.load(
    ROOT / "models" / "fraud_model.joblib"
)

st.set_page_config(
    page_title="Fraud Detection",
    page_icon="🛡️"
)

st.title("🛡️ Fraud Detection System")

st.write(
    "Enter transaction details to estimate "
    "whether a transaction looks suspicious."
)

amount = st.number_input(
    "Transaction Amount",
    min_value=0.0,
    value=850.0
)

hour = st.slider(
    "Transaction Hour",
    0,
    23,
    12
)

count = st.number_input(
    "Transactions In Recent Period",
    min_value=1,
    value=3
)

risk = st.slider(
    "Merchant Risk",
    0.0,
    1.0,
    0.50
)

distance = st.number_input(
    "Distance From Home (km)",
    min_value=0.0,
    value=10.0
)

if st.button("Check Transaction"):

    X = pd.DataFrame([{
        "amount": amount,
        "transaction_hour": hour,
        "transaction_count": count,
        "merchant_risk": risk,
        "distance_from_home": distance
    }])

    pred = int(
        model.predict(X)[0]
    )

    prob = float(
        model.predict_proba(X)[0, 1]
    )

    if pred:

        st.error(
            f"Potential Fraud Transaction — "
            f"probability {prob:.2%}"
        )

    else:

        st.success(
            f"Likely Normal Transaction — "
            f"fraud probability {prob:.2%}"
        )

st.caption(
    "Academic demonstration only."
)