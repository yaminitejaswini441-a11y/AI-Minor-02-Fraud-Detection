from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent

model = joblib.load(
    ROOT / "models" / "fraud_model.joblib"
)

sample = pd.DataFrame([{
    "amount": 850.0,
    "transaction_hour": 2,
    "transaction_count": 7,
    "merchant_risk": 0.92,
    "distance_from_home": 35.0
}])

prediction = int(
    model.predict(sample)[0]
)

probability = float(
    model.predict_proba(sample)[0, 1]
)

print("=== SAMPLE TRANSACTION ===")

print(
    sample.to_string(index=False)
)

print(
    "\nPrediction:",
    "FRAUD" if prediction else "NOT FRAUD"
)

print(
    "Fraud probability:",
    round(probability, 4)
)