from pathlib import Path
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report


BASE_DIR = Path(__file__).resolve().parents[1]

DATA_PATH = BASE_DIR / "data" / "cleaned_fraud_data.csv"
MODEL_DIR = BASE_DIR / "models"
MODEL_PATH = MODEL_DIR / "fraud_model.joblib"

MODEL_DIR.mkdir(parents=True, exist_ok=True)


print("Loading dataset...")

df = pd.read_csv(DATA_PATH)

print("Dataset Loaded Successfully")
print("Rows:", len(df))
print("Columns:", list(df.columns))


X = df.drop(columns=["is_fraud"])
y = df["is_fraud"]


X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


print("Training model...")


model = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    class_weight="balanced"
)

model.fit(X_train, y_train)


predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)


print()
print("Fraud Detection Model")
print("----------------------")
print(f"Accuracy: {accuracy:.2%}")
print()
print("Classification Report:")
print(classification_report(y_test, predictions))


joblib.dump(model, MODEL_PATH)

print()
print("Model saved successfully!")
print("Model path:", MODEL_PATH)