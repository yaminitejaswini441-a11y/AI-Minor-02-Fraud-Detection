from pathlib import Path

import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report


BASE_DIR = Path(__file__).resolve().parents[1]

DATA_PATH = BASE_DIR / "data" / "cleaned_fraud_data.csv"
MODEL_PATH = BASE_DIR / "models" / "fraud_model.joblib"


df = pd.read_csv(DATA_PATH)

X = df.drop(columns=["is_fraud"])
y = df["is_fraud"]


X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


model = joblib.load(MODEL_PATH)

predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)


print()
print("================================")
print("FRAUD DETECTION MODEL EVALUATION")
print("================================")

print(f"Accuracy: {accuracy:.2%}")

print()
print("Classification Report:")
print(classification_report(y_test, predictions))