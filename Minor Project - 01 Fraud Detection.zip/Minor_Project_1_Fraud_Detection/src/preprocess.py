from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

raw = DATA / "fraud_data.csv"
clean = DATA / "cleaned_fraud_data.csv"

if not raw.exists():
    rng = np.random.default_rng(42)
    n = 2500

    amount = np.round(rng.lognormal(3.8, 1.0, n), 2)
    hour = rng.integers(0, 24, n)
    tx_count = rng.poisson(3, n) + 1
    merchant_risk = rng.random(n)
    distance = np.round(rng.exponential(15, n), 2)

    score = (
        0.0025 * amount
        + 0.9 * (hour < 5)
        + 1.4 * (merchant_risk > 0.78)
        + 0.018 * distance
        + 0.15 * tx_count
        + rng.normal(0, 0.8, n)
    )

    threshold = np.quantile(score, 0.90)
    is_fraud = (score > threshold).astype(int)

    df = pd.DataFrame({
        "amount": amount,
        "transaction_hour": hour,
        "transaction_count": tx_count,
        "merchant_risk": np.round(merchant_risk, 3),
        "distance_from_home": distance,
        "is_fraud": is_fraud
    })

    df.to_csv(raw, index=False)
    print(f"Created demo dataset: {raw}")

df = pd.read_csv(raw)

df = df.drop_duplicates().dropna()

df.to_csv(clean, index=False)

print(f"Saved cleaned dataset: {clean}")
print(df.head())

print("\nClass counts:")
print(df["is_fraud"].value_counts())