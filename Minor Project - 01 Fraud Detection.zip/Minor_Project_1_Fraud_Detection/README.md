# Fraud Detection System

## Project Overview

Fraud Detection System is a machine learning based application used to identify whether a financial transaction appears normal or potentially fraudulent.

## Objectives

- Detect potentially fraudulent transactions
- Use machine learning for classification
- Display fraud probability
- Provide a simple web interface
- Evaluate model performance

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Joblib
- Streamlit

## Input Features

- Transaction Amount
- Transaction Hour
- Transaction Count
- Merchant Risk
- Distance From Home

## Machine Learning Model

Random Forest Classifier

## Project Structure

```text
Minor_Project_1_Fraud_Detection
│
├── app
│   └── app.py
│
├── data
│   ├── fraud_data.csv
│   └── cleaned_fraud_data.csv
│
├── models
│   └── fraud_model.joblib
│
├── notebooks
│
├── reports
│
├── src
│   ├── preprocess.py
│   ├── train.py
│   └── evaluate.py
│
├── predict.py
├── requirements.txt
└── README.md